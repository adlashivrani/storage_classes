extern int a;
static int c = 3;
void func4()
{
	printf("\nfunc4: %d, %d\n", a, c);
}
void func5()
{
	printf("\nfunc5: %d %d\n", a, c);
}
