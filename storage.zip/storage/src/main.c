int a = 1;
int main()
{
	func1();
	func2();
	func3();
	func4();
	func5();
	return 0;
}


