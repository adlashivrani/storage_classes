extern int a;
static int d = 4;
void func1()
{
	printf("\nfunc1: %d, %d\n", a, d);
}
void func2()
{
	printf("\nfunc2: %d, %d\n", a, d);
}
