extern int a;
void func3()
{	auto int b = 2;
	printf("\nfunc3: %d,%d\n", a, b);
}
